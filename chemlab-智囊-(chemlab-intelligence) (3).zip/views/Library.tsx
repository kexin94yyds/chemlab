import React, { useState, useRef, useEffect } from 'react';
import { 
  Search, Library, Bookmark, Book, Database, FileText, Loader2, 
  Thermometer, Droplet, Hash, ChevronRight, Plus, X, Upload, 
  File, FileType, CheckCircle2, ExternalLink, ShieldCheck, Save, Beaker, Trash2, Sparkles,
  // Fix: replaced ShieldInfo with ShieldAlert which is the correct lucide-react icon
  BookOpen, Globe, Download, Eye, Clock, ShieldAlert
} from 'lucide-react';
import { lookupChemicalProperties, searchStandards } from '../services/geminiService';
import { Reagent, Standard, SOP } from '../types';

// 初始预置试剂数据库
const INITIAL_REAGENTS: Reagent[] = [
  { name: '无水乙醇', cas: '64-17-5', mw: 46.07, density: 0.789, mp: '-114.1 ℃', bp: '78.37 ℃', solubility: '与水混溶' },
  { name: '二氯甲烷 (DCM)', cas: '75-09-2', mw: 84.93, density: 1.325, mp: '-96.7 ℃', bp: '39.6 ℃', solubility: '13.2 g/L' },
  { name: '硫酸', cas: '7664-93-9', mw: 98.08, density: 1.84, mp: '10.31 ℃', bp: '337 ℃', solubility: '与水混溶' },
  { name: '乙酸乙酯 (EA)', cas: '141-78-6', mw: 88.11, density: 0.902, mp: '-83.6 ℃', bp: '77.1 ℃', solubility: '83 g/L' },
];

// 初始预置标准库
const INITIAL_STANDARDS: Standard[] = [
  { id: 'std-01', code: 'GB 2760-2024', title: '食品安全国家标准 食品添加剂使用标准', category: '食品安全', summary: '规定了食品中允许使用的添加剂品种、使用范围及最大使用量。2024版最新修订。' },
  { id: 'std-02', code: 'GB 5009.3-2016', title: '食品安全国家标准 食品中水分的测定', category: '理化检验', summary: '规定了食品中水分测定的几种常用方法，包括直接干燥法、减压干燥法等。' },
  { id: 'std-03', code: 'GB/T 191', title: '包装储运图示标志', category: '包装运输', summary: '规定了包装储运图示标志的名称、图形、尺寸、颜色及应用方法。' },
  { id: 'std-04', code: 'GB 2761-2017', title: '食品安全国家标准 食品中真菌毒素限量', category: '污染物限制', summary: '规定了食品中黄曲霉毒素、赭共霉毒素等真菌毒素的限量要求。' }
];

const LibraryView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'property' | 'standard' | 'method'>('property');
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [propertyResult, setPropertyResult] = useState<{data: Reagent, isAI: boolean} | null>(null);
  
  // Standards State
  const [savedStandards] = useState<Standard[]>(INITIAL_STANDARDS);
  const [standardResults, setStandardResults] = useState<{data: Standard[], source: 'local' | 'ai'} | null>(null);

  // Reagent State
  const [savedReagents, setSavedReagents] = useState<Reagent[]>([]);
  const [isAddingReagent, setIsAddingReagent] = useState(false);
  const [newReagent, setNewReagent] = useState<Partial<Reagent>>({ name: '', cas: '', mw: 0 });

  // SOP State
  const [isAddingSOP, setIsAddingSOP] = useState(false);
  const [selectedSOP, setSelectedSOP] = useState<SOP | null>(null);
  const [newSOPTitle, setNewSOPTitle] = useState('');
  const [newSOPCategory, setNewSOPCategory] = useState('溶剂处理');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [methods, setMethods] = useState<SOP[]>([
    { 
      id: 'sop-01', 
      title: '无水乙醇脱水处理 (SOP)', 
      category: '溶剂处理', 
      fileType: 'pdf', 
      fileName: 'ethanol_drying.pdf',
      steps: ['加入活化好的分子筛 (3A/4A)', '静置 24-48 小时', '减压蒸馏取馏分', '密封保存于干燥柜'],
      precautions: '分子筛需在 300℃ 下活化 6 小时以上方可使用。'
    },
    { 
      id: 'sop-02', 
      title: '柱层析装柱标准化操作', 
      category: '分离纯化', 
      fileType: 'docx', 
      fileName: 'column_chromatography.docx',
      steps: ['准备干硅胶与溶剂混悬', '湿法装柱，排除气泡', '用溶剂平衡 2-3 个柱体积', '上样并开始洗脱'],
      precautions: '装柱过程中切勿干柱，以免影响分离效果。'
    },
    { 
      id: 'sop-03', 
      title: '重结晶通用溶剂筛选法', 
      category: '纯化', 
      fileType: 'md', 
      fileName: 'recrystallization_guide.md',
      steps: ['取少量样品置于试管', '依次滴加不同极性溶剂', '加热回流观察溶解性', '室温静置看晶体析出情况'],
      precautions: '注意易燃溶剂的加热安全，必须使用水浴或油浴。'
    },
  ]);

  // Sync Logic
  useEffect(() => {
    const stored = localStorage.getItem('chem_saved_reagents');
    setSavedReagents(stored ? JSON.parse(stored) : INITIAL_REAGENTS);
  }, []);

  useEffect(() => {
    localStorage.setItem('chem_saved_reagents', JSON.stringify(savedReagents));
  }, [savedReagents]);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);

    if (activeTab === 'property') {
      const localMatch = savedReagents.find(r => 
        r.name.toLowerCase().includes(query.toLowerCase()) || r.cas.includes(query)
      );
      if (localMatch) {
        setPropertyResult({ data: localMatch, isAI: false });
      } else {
        const res = await lookupChemicalProperties(query);
        if (res) setPropertyResult({ data: res, isAI: true });
      }
    } else if (activeTab === 'standard') {
      const localMatches = savedStandards.filter(s => 
        s.title.toLowerCase().includes(query.toLowerCase()) || 
        s.code.toLowerCase().includes(query.toLowerCase())
      );
      if (localMatches.length > 0) {
        setStandardResults({ data: localMatches, source: 'local' });
      } else {
        const res = await searchStandards(query);
        setStandardResults(res.length > 0 ? { data: res, source: 'ai' } : null);
      }
    }
    setLoading(false);
  };

  const handleSaveReagent = (reagent: Reagent) => {
    if (savedReagents.some(r => r.cas === reagent.cas)) return alert("已在库中");
    setSavedReagents([reagent, ...savedReagents]);
  };

  const handleDownload = (sop: SOP) => {
    setLoading(true);
    // 模拟下载延迟
    setTimeout(() => {
      setLoading(false);
      alert(`已成功从云端存证服务器检索到文件: ${sop.fileName}\n正在为您准备本地副本...`);
    }, 1200);
  };

  const getFileIcon = (type?: string) => {
    if (type === 'pdf') return <FileType className="w-5 h-5 text-rose-500" />;
    if (type === 'docx') return <FileText className="w-5 h-5 text-blue-500" />;
    return <File className="w-5 h-5 text-slate-400" />;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-800">知识与标准库</h2>
        <Library className="w-6 h-6 text-indigo-500" />
      </div>

      <div className="flex p-1 bg-slate-200 rounded-xl">
        {(['property', 'standard', 'method'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === tab ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {tab === 'property' ? '物化性质' : tab === 'standard' ? '国标/行标' : '常用方法'}
          </button>
        ))}
      </div>

      {activeTab !== 'method' && (
        <div className="space-y-4">
          {activeTab === 'standard' && (
            <div className="flex items-center justify-between p-4 bg-indigo-50 border border-indigo-100 rounded-[1.5rem] shadow-sm">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-white rounded-full shadow-sm">
                   <ShieldCheck className="w-4 h-4 text-indigo-600" />
                </div>
                <div>
                  <span className="text-xs font-black text-indigo-900 block">食品伙伴网官方库直连</span>
                  <p className="text-[9px] text-indigo-600/70 font-bold uppercase tracking-widest mt-0.5 italic">OFFLINE SYNCED | LIVE AI DUAL-MODE</p>
                </div>
              </div>
              <a href="https://db.foodmate.net/" target="_blank" rel="noopener noreferrer" className="px-4 py-1.5 bg-indigo-600 text-white text-[10px] font-black rounded-full flex items-center hover:bg-indigo-700 transition-all shadow-md">
                前往官方库 <ExternalLink className="w-3 h-3 ml-2" />
              </a>
            </div>
          )}

          <div className="flex space-x-2">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder={activeTab === 'property' ? '搜索库中试剂名或 CAS...' : '输入标准号或关键词 (如: GB 2760)...'}
                className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm font-medium"
              />
            </div>
            <button
              onClick={handleSearch}
              disabled={loading}
              className="px-6 py-2 bg-indigo-600 text-white rounded-2xl font-black hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center shadow-lg active:scale-95"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '检索'}
            </button>
          </div>
        </div>
      )}

      {/* Property Tab Content omitted for brevity but preserved */}
      {activeTab === 'property' && (
        <div className="space-y-6">
           {propertyResult && (
            <div className="animate-in fade-in slide-in-from-top-4">
              <div className={`p-6 rounded-[2.5rem] border ${propertyResult.isAI ? 'bg-white border-indigo-100 shadow-xl' : 'bg-slate-900 text-white border-slate-800 shadow-xl'} relative overflow-hidden`}>
                <div className="absolute top-0 right-0 p-6 flex items-center space-x-2">
                  <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full ${propertyResult.isAI ? 'bg-indigo-50 text-indigo-400' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-400/20'}`}>
                    {propertyResult.isAI ? 'AI 智囊检索' : '官方库已入库'}
                  </span>
                  {propertyResult.isAI && (
                    <button onClick={() => handleSaveReagent(propertyResult.data)} className="p-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 shadow-lg shadow-indigo-200">
                      <Save className="w-5 h-5" />
                    </button>
                  )}
                </div>
                <div className="mb-8">
                  <h3 className={`text-2xl font-black ${propertyResult.isAI ? 'text-slate-800' : 'text-white'}`}>{propertyResult.data.name}</h3>
                  <p className={`text-xs font-bold uppercase tracking-[0.2em] mt-2 ${propertyResult.isAI ? 'text-indigo-500' : 'text-slate-400'}`}>CAS: {propertyResult.data.cas}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: '分子量', val: `${propertyResult.data.mw} g/mol`, icon: Hash },
                    { label: '密度', val: propertyResult.data.density ? `${propertyResult.data.density} g/cm³` : 'N/A', icon: Droplet },
                    { label: '熔/沸点', val: `${propertyResult.data.mp || '-'} / ${propertyResult.data.bp || '-'}`, icon: Thermometer },
                    { label: '溶解度/pKa', val: `${propertyResult.data.solubility || '-'} / ${propertyResult.data.pKa || '-'}`, icon: ShieldCheck }
                  ].map((item, idx) => (
                    <div key={idx} className={`flex items-start space-x-3 p-4 rounded-3xl ${propertyResult.isAI ? 'bg-slate-50' : 'bg-white/5 border border-white/10'}`}>
                      <item.icon className={`w-4 h-4 mt-0.5 ${propertyResult.isAI ? 'text-indigo-400' : 'text-slate-500'}`} />
                      <div>
                        <p className={`text-[10px] font-bold uppercase tracking-widest mb-1 ${propertyResult.isAI ? 'text-slate-400' : 'text-slate-500'}`}>{item.label}</p>
                        <p className={`text-sm font-bold ${propertyResult.isAI ? 'text-slate-700' : 'text-slate-200'}`}>{item.val}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          {/* ... existing reagent catalog content ... */}
          <div className="space-y-4">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center ml-1">
              <Database className="w-4 h-4 mr-2 text-indigo-400" /> 我的数据库目录 ({savedReagents.length})
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {savedReagents.map((r, i) => (
                <div key={i} onClick={() => { setQuery(r.name); handleSearch(); }} className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-[2rem] hover:bg-slate-50 hover:border-indigo-300 transition-all cursor-pointer group shadow-sm">
                  <div className="flex items-center space-x-3">
                    <div className="p-2.5 bg-indigo-50 text-indigo-500 rounded-2xl group-hover:bg-indigo-500 group-hover:text-white transition-all"><Beaker className="w-5 h-5" /></div>
                    <div className="overflow-hidden"><p className="text-sm font-black text-slate-800 truncate leading-tight">{r.name}</p><p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">CAS: {r.cas}</p></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Standard Tab Content preserved */}
      {activeTab === 'standard' && (
        <div className="space-y-4">
          {standardResults ? (
            <div className="space-y-4 animate-in fade-in">
              {standardResults.data.map((std, i) => (
                <div key={i} className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm hover:border-indigo-400 transition-all group relative overflow-hidden">
                  <div className={`absolute top-0 right-0 px-4 py-1.5 text-[8px] font-black uppercase tracking-tighter rounded-bl-xl border-l border-b ${standardResults.source === 'local' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-indigo-50 text-indigo-600 border-indigo-100'}`}>
                    {standardResults.source === 'local' ? 'Official Local DB' : 'AI Live Search'}
                  </div>
                  <div className="flex justify-between items-start mb-3">
                    <span className={`px-3 py-1 text-[10px] font-black rounded-full border ${standardResults.source === 'local' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-indigo-50 text-indigo-700 border-indigo-100'}`}>{std.code}</span>
                    <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{std.category}</span>
                  </div>
                  <h4 className="font-black text-slate-800 mb-3 group-hover:text-indigo-600 transition-colors text-lg leading-snug">{std.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed mb-5 line-clamp-3 bg-slate-50 p-3 rounded-xl border border-slate-100 italic">“{std.summary}”</p>
                  <a href={`https://db.foodmate.net/search.php?query=${encodeURIComponent(std.code)}`} target="_blank" rel="noopener noreferrer" className="w-full py-2.5 bg-indigo-600 text-white rounded-xl text-[10px] font-black flex items-center justify-center shadow-lg hover:bg-indigo-700 transition-all active:scale-95">全文查询 <ExternalLink className="w-3.5 h-3.5 ml-2" /></a>
                </div>
              ))}
            </div>
          ) : !loading && (
             <div className="p-12 text-center bg-slate-50 rounded-[2.5rem] border-2 border-dashed border-slate-200">
               <BookOpen className="w-12 h-12 text-slate-200 mx-auto mb-4" />
               <p className="text-sm text-slate-400 font-bold">输入标准号进行混合检索</p>
             </div>
          )}
        </div>
      )}

      {/* Method Tab (UPDATED with View/Download) */}
      {activeTab === 'method' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">私有 SOP 与标准化文件库</h3>
            <button onClick={() => setIsAddingSOP(true)} className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-full text-xs font-bold hover:bg-indigo-700 shadow-lg active:scale-95"><Plus className="w-4 h-4 mr-2" /> 录入存证</button>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {methods.map((method, i) => (
              <div 
                key={i} 
                onClick={() => setSelectedSOP(method)}
                className="flex items-center justify-between p-5 bg-white border border-slate-200 rounded-[2.5rem] hover:bg-slate-50 hover:border-indigo-400 transition-all cursor-pointer group shadow-sm border-l-4 border-l-transparent hover:border-l-indigo-600"
              >
                <div className="flex items-center space-x-5">
                  <div className="p-3 bg-slate-100 rounded-2xl group-hover:bg-white group-hover:shadow-md transition-all">{getFileIcon(method.fileType)}</div>
                  <div>
                    <p className="text-md font-black text-slate-800 group-hover:text-indigo-600 transition-colors">{method.title}</p>
                    <div className="flex items-center mt-1.5 space-x-3">
                      <span className="text-[10px] text-indigo-500 font-black uppercase bg-indigo-50 px-2 py-0.5 rounded-md">{method.category}</span>
                      <span className="text-[10px] text-slate-400 font-bold flex items-center"><Eye className="w-3 h-3 mr-1" /> 点击预览详情</span>
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-indigo-400 group-hover:translate-x-1 transition-all" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SOP Preview Modal */}
      {selectedSOP && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in duration-300 flex flex-col max-h-[90vh]">
            <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-white rounded-2xl shadow-sm border border-slate-100">
                  {getFileIcon(selectedSOP.fileType)}
                </div>
                <div>
                  <h3 className="text-xl font-black text-slate-800 leading-tight">{selectedSOP.title}</h3>
                  <div className="flex items-center mt-1 space-x-4">
                    <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest bg-indigo-50 px-2 py-0.5 rounded-md">ID: {selectedSOP.id}</span>
                    <span className="text-[10px] font-bold text-slate-400 flex items-center"><Clock className="w-3 h-3 mr-1" /> 2024-05-22 更新</span>
                  </div>
                </div>
              </div>
              <button onClick={() => setSelectedSOP(null)} className="p-2 hover:bg-slate-200 rounded-full transition-colors text-slate-400"><X className="w-6 h-6" /></button>
            </div>

            <div className="p-10 space-y-8 overflow-y-auto flex-1 custom-scrollbar">
              {/* SOP Steps */}
              <div className="space-y-4">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center">
                   <BookOpen className="w-4 h-4 mr-2 text-indigo-400" /> 标准操作步骤 (SOP)
                </h4>
                <div className="space-y-3">
                  {(selectedSOP.steps || ['暂无详细步骤描述']).map((step, idx) => (
                    <div key={idx} className="flex items-start space-x-4 group">
                      <div className="w-6 h-6 bg-slate-100 text-slate-500 rounded-full flex items-center justify-center text-[10px] font-black flex-shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                        {idx + 1}
                      </div>
                      <p className="text-sm font-medium text-slate-700 pt-0.5 leading-relaxed">{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Precautions */}
              <div className="p-6 bg-rose-50 rounded-3xl border border-rose-100">
                <h4 className="text-xs font-black text-rose-600 uppercase tracking-widest flex items-center mb-3">
                  {/* Fix: replaced ShieldInfo with ShieldAlert which is the correct lucide-react icon */}
                  <ShieldAlert className="w-4 h-4 mr-2" /> 安全注意事项
                </h4>
                <p className="text-sm text-rose-900 leading-relaxed font-medium">
                  {selectedSOP.precautions || '实验室通用安全守则适用。'}
                </p>
              </div>

              {/* File Info */}
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 border-dashed">
                <div className="flex items-center space-x-3">
                   <div className="text-slate-400 font-bold text-[10px] uppercase">原始存证名:</div>
                   <div className="text-slate-600 font-black text-xs">{selectedSOP.fileName}</div>
                </div>
                <div className="text-slate-400 font-bold text-[10px] uppercase">Size: 1.2 MB</div>
              </div>
            </div>

            <div className="p-8 border-t border-slate-100 bg-slate-50/30 flex space-x-4">
              <button 
                onClick={() => setSelectedSOP(null)}
                className="flex-1 py-4 bg-white border border-slate-200 rounded-2xl font-black text-slate-600 hover:bg-slate-50 transition-all"
              >
                关闭预览
              </button>
              <button 
                onClick={() => handleDownload(selectedSOP)}
                disabled={loading}
                className="flex-2 px-12 py-4 bg-indigo-600 text-white rounded-2xl font-black shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center active:scale-95"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Download className="w-5 h-5 mr-2" />}
                下载原始存证文件
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Reagent & SOP Modals (Keep from previous implementation) */}
      {isAddingSOP && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl animate-in zoom-in">
            <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-indigo-50/20">
              <h3 className="text-xl font-black text-slate-800">方法录入存证</h3>
              <button onClick={() => setIsAddingSOP(false)} className="p-2 hover:bg-white rounded-full"><X className="w-6 h-6 text-slate-400" /></button>
            </div>
            <div className="p-8 space-y-6">
              <input type="text" placeholder="方法名称" value={newSOPTitle} onChange={e => setNewSOPTitle(e.target.value)} className="w-full px-5 py-4 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none" />
              <div onClick={() => fileInputRef.current?.click()} className={`mt-1 border-2 border-dashed rounded-[2rem] p-10 flex flex-col items-center justify-center cursor-pointer ${selectedFile ? 'bg-emerald-50 border-emerald-300' : 'bg-slate-50 hover:bg-slate-100'}`}>
                <input type="file" ref={fileInputRef} className="hidden" onChange={e => setSelectedFile(e.target.files?.[0] || null)} />
                {selectedFile ? <><CheckCircle2 className="w-10 h-10 text-emerald-500 mb-3" /><p className="text-sm font-black text-emerald-700">{selectedFile.name}</p></> : <><Upload className="w-10 h-10 text-slate-300 mb-3" /><p className="text-xs font-bold text-slate-400">点击上传 PDF, DOCX, MD</p></>}
              </div>
              <button onClick={() => { setMethods([...methods, {id: Date.now().toString(), title: newSOPTitle, category: newSOPCategory, fileName: selectedFile?.name, fileType: 'pdf'}]); setIsAddingSOP(false); }} className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black shadow-xl">开始同步</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LibraryView;