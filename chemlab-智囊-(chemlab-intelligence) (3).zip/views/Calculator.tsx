
import React, { useState, useEffect } from 'react';
import { Search, Loader2, Info, RefreshCw, Layers } from 'lucide-react';
import { lookupChemicalProperties } from '../services/geminiService';
import { Reagent } from '../types';

const Calculator: React.FC = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [reagent, setReagent] = useState<Reagent | null>(null);
  
  const [concentration, setConcentration] = useState<string>('');
  const [volume, setVolume] = useState<string>('');
  const [result, setResult] = useState<{ weight?: number; volume?: number } | null>(null);

  const handleLookup = async () => {
    if (!query.trim()) return;
    setLoading(true);
    const data = await lookupChemicalProperties(query);
    setReagent(data);
    setLoading(false);
  };

  useEffect(() => {
    if (reagent && concentration && volume) {
      const c = parseFloat(concentration); // M
      const v = parseFloat(volume); // mL
      const vInL = v / 1000;
      const weight = c * vInL * reagent.mw;
      
      let liquidVolume: number | undefined = undefined;
      if (reagent.density) {
        liquidVolume = weight / reagent.density;
      }
      
      setResult({ weight, volume: liquidVolume });
    } else {
      setResult(null);
    }
  }, [reagent, concentration, volume]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-800">智能计算工具箱</h2>
        <RefreshCw className="w-5 h-5 text-emerald-500" />
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-6">
        {/* Step 1: Lookup */}
        <div>
          <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">1. 试剂参数检索</label>
          <div className="flex space-x-2">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="搜索试剂名获取 MW & 密度..."
              className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
            />
            <button
              onClick={handleLookup}
              disabled={loading}
              className="px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {reagent && (
          <div className="flex items-center justify-between p-4 bg-emerald-50 rounded-2xl border border-emerald-100 animate-in fade-in">
            <div>
              <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-widest">已匹配</p>
              <p className="text-sm font-black text-slate-800">{reagent.name}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-emerald-600 font-bold">MW: {reagent.mw}</p>
              {reagent.density && <p className="text-[10px] text-emerald-600 font-bold">ρ: {reagent.density} g/mL</p>}
            </div>
          </div>
        )}

        {/* Step 2: Inputs */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1.5">目标浓度 (M)</label>
            <input
              type="number"
              value={concentration}
              onChange={(e) => setConcentration(e.target.value)}
              className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1.5">目标体积 (mL)</label>
            <input
              type="number"
              value={volume}
              onChange={(e) => setVolume(e.target.value)}
              className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>
        </div>

        {/* Result */}
        {result && (
          <div className="p-6 bg-slate-900 rounded-3xl text-white shadow-xl animate-in zoom-in">
            <div className="flex items-center space-x-2 mb-4 opacity-50">
              <Layers className="w-3 h-3" />
              <span className="text-[10px] font-bold uppercase tracking-widest">称量/量取建议</span>
            </div>
            
            <div className="grid grid-cols-1 gap-6">
              <div>
                <p className="text-slate-400 text-[10px] uppercase font-bold mb-1">如果是固体 (质量)</p>
                <p className="text-3xl font-black text-emerald-400">
                  {result.weight?.toFixed(4)} <span className="text-sm font-normal text-white/50">g</span>
                </p>
              </div>
              
              {result.volume && (
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-bold mb-1">如果是液体 (体积)</p>
                  <p className="text-3xl font-black text-sky-400">
                    {result.volume?.toFixed(4)} <span className="text-sm font-normal text-white/50">mL</span>
                  </p>
                </div>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-center text-[9px] text-white/40 italic">
              <Info className="w-3 h-3 mr-1.5" /> 自动同步知识库物理常数进行计算
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Calculator;
